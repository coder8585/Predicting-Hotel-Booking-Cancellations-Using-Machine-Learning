```text
├── data/
│   ├── raw/                # Original, immutable data dumps
│   └── processed/          # Cleaned and processed data ready for training
```
