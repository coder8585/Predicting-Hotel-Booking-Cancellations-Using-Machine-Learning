```text
├── notebooks/              # Jupyter notebooks for exploration and prototyping
│   └── Chad 207 Project Notebook.ipynb # Chad Vo
    └── emily_zhao_final_project.ipynb # Emily Zhao
    └── kristen_project_nb.ipynb # Kristin Lin
```